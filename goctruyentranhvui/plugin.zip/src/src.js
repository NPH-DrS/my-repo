if (typeof BASE_URL !== 'undefined'){
    const BASE_URL = "https://goctruyentranhvui3.com";
}

const TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJRaSIsImNvbWljSWRzIjpbXSwicm9sZUlkIjpudWxsLCJncm91cElkIjpudWxsLCJhZG1pbiI6ZmFsc2UsInJhbmsiOjEsInBlcm1pc3Npb24iOltdLCJpZCI6IjAwMDAxMDAxNDEiLCJ0ZWFtIjpmYWxzZSwiaWF0IjoxNzIxNzMyNDM3LCJlbWFpbCI6Im51bGwifQ.2ZWVj-r6Uxwor3hIhBPXbOlcrgG34e54uj3JFZRgcLZfmnfe7VguSiEgkc19dpi04UWILDgylOmo67MANjDeAA";