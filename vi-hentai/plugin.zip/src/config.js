var BASE_URL = 'https://vi-hentai.moe';
if(CONFIG_URL != null){
    BASE_URL = CONFIG_URL
}