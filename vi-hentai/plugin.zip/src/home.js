function execute() {
    return Response.success([
        {
            title: "Trang chủ", 
            input: "https://vi-hentai.com/danh-sach", 
            script: "gen.js"
        }
    ]);
}